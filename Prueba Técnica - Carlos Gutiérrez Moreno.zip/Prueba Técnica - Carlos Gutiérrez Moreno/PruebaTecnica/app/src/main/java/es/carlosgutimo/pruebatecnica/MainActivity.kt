package es.carlosgutimo.pruebatecnica

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import es.carlosgutimo.pruebatecnica.`class`.Accounts
import kotlinx.android.synthetic.main.accounts_listviewticket.view.*
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream


class MainActivity : AppCompatActivity() {
    private var adapter: AccountsAdapter? = null
    private var listOfAccounts = ArrayList<Accounts>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // We assign the App Title
        title = getString(R.string.home)

        // We load every loaded account from the provided + edited JSON
        updateAccounts()

        // We handle the Show/Hide "Private accounts" and store it in preferences, just in case the user wants the changes to stay the same after reboot
        val settings: SharedPreferences = this.getSharedPreferences("PREFS", 0)
        if (!settings.getBoolean("showAccounts", false)) {
            removeShowHideAccounts.visibility = View.INVISIBLE
        }
        else{
            removeShowHideAccounts.visibility = View.VISIBLE
        }
        showHideAccounts.setOnClickListener {
            if (!settings.getBoolean("showAccounts", false)) {
                settings.edit().putBoolean("showAccounts", true).apply()
                updateAccounts()
                removeShowHideAccounts.visibility = View.VISIBLE
            } else {
                settings.edit().putBoolean("showAccounts", false).apply()
                updateAccounts()
                removeShowHideAccounts.visibility = View.INVISIBLE
            }
        }
    }

    private fun updateAccounts() {
        val settings: SharedPreferences =
            this.getSharedPreferences("PREFS", 0)
        val isVisible = settings.getBoolean("showAccounts", false)

        // We clear the ArrayList, to make sure we only show Visible/All Accounts
        listOfAccounts.clear()

        // We load the "accounts.json" from the assets folder
        var jsonObj: JSONArray? = null
        val json: String?
        try {
            val inputStream: InputStream = assets.open("accounts.json")
            json = inputStream.bufferedReader().use { it.readText() }
            jsonObj = JSONObject(json).getJSONArray("accounts")
        } catch (e: Exception) {
            // In case of an error, we handle it showing an error message
            Toast.makeText(this, getString(R.string.error_loading_json), Toast.LENGTH_SHORT).show()
        }

        // We assign the adapter and load each account info
        adapter = AccountsAdapter(listOfAccounts, this)
        Accounts_ListView.adapter = adapter
        var currentAccount = 0

        // We loop trough the accounts and add them to the ArrayList of Accounts
        while (currentAccount <= jsonObj!!.length() - 1) {
            val current = jsonObj.getJSONObject(currentAccount)
            val balance = current.getInt("accountBalanceInCents")
            var currency: String? = null
            when (current.getString("accountCurrency")) {
                "EUR" -> {
                    currency = "€"
                }
                "USD" -> {
                    currency = "$"
                }
                "GBP" -> {
                    currency = "£"
                }
                "JPY" -> {
                    currency = "¥"
                }
            }
            val id = current.getInt("accountId")
            val name = current.getString("accountName")
            val number = current.getString("accountNumber")
            val accountType = current.getString("accountType")
            val alias = current.getString("alias")
            val iban = current.getString("iban")
            val visibility = current.getBoolean("isVisible")

            if (isVisible && !visibility || isVisible && visibility || !isVisible && visibility)
                if (accountType == "SAVING") {
                    // We handle any "SAVING" Account
                    val linkedAccount = current.getInt("linkedAccountId")
                    val productName = current.getString("productName")
                    val productType = current.getInt("productType")
                    val savingReached = current.getInt("savingsTargetReached")
                    val targetAmount = current.getInt("targetAmountInCents")

                    listOfAccounts.add(Accounts(balance, currency!!, id, name, number, accountType, alias, visibility, iban, linkedAccount, productName, productType, savingReached, targetAmount))
                } else {
                    // We handle any "PAYMENT" Account and set the extra info to 0 or null
                    listOfAccounts.add(Accounts(balance, currency!!,  id, name, number, accountType, alias, visibility, iban, 0, "", 0, 0,0))
                }
            currentAccount++
            adapter!!.notifyDataSetChanged()
        }
    }

    // This is the adapter used to fill in the ListView with the JSON Accounts
    class AccountsAdapter(private var listOfAccounts: ArrayList<Accounts>, context: Context) : BaseAdapter() {
        private var context: Context? = context

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val accounts = listOfAccounts[position]
            val inflater =
                context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val accountsView = inflater.inflate(R.layout.accounts_listviewticket, null)

            // We load the info into the ticket
            accountsView.accountName.text = accounts.name
            accountsView.accountBalance.text = accounts.balance.toString()
            accountsView.accountCurrency.text = accounts.currency
            accountsView.accountIBAN.text = accounts.iban

            // We handle the (i) click
            accountsView.accountInfo.setOnClickListener {
                val settings: SharedPreferences = context!!.getSharedPreferences("PREFS", 0)
                val accountInfo = InfoPop()
                val fm = (context as AppCompatActivity).supportFragmentManager
                settings.edit().putString("AccountType", accounts.type).apply()
                settings.edit().putString("LinkedAccount", accounts.linkedAccount.toString()).apply()
                settings.edit().putString("accountProduct", accounts.productName).apply()
                settings.edit().putString("accountProgress", accounts.targetAmount.toString()).apply()
                accountInfo.show(fm, "Account Info")
            }

            // We handle the ticket click
            accountsView.accountDetails.setOnClickListener {
                val intent = Intent(context, AccountsActivity::class.java)
                // We send the intent the information
                intent.putExtra("Type", accounts.type)
                intent.putExtra("IBAN", accounts.iban)
                intent.putExtra("Name", accounts.name)
                intent.putExtra("Currency", accounts.currency)
                intent.putExtra("Balance", accounts.balance)
                intent.putExtra("Progress", accounts.targetAmount)
                context!!.startActivity(intent)
            }

            return accountsView
        }

        override fun getItem(position: Int): Any {
            return listOfAccounts[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return listOfAccounts.size
        }
    }
}
