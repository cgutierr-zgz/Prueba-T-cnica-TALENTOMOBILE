package es.carlosgutimo.pruebatecnica


import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import kotlinx.android.synthetic.main.info_pop.*
// We use this as a "POPUP" Window, to show info to the user
class InfoPop : DialogFragment() {
    private var mContext: Context? = null
    override fun onAttach(context: Context) {
        super.onAttach(context)
        mContext = context
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.info_pop, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val settings: SharedPreferences = context!!.getSharedPreferences("PREFS", 0)
        val accountType = settings.getString("AccountType", "")
        accountType_POP.text = accountType
        //We generate a random Phone number, to make it look better...
        accountPhone_POP.text = "+34 ${(613765906..713362106).random()}"
        if (accountType == "SAVING") {
            // We handle SAVING Accounts
            linkedAccount_POP.text = settings.getString("LinkedAccount", "")
            accountProduct_POP.text = settings.getString("accountProduct", "")
            accountProgress_POP.text = settings.getString("accountProgress", "")
        } else {
            // We handle the other Accounts
            layout_linkedAccount_POP.visibility = View.GONE
            layout_accountProduct_POP.visibility = View.GONE
            layout_accountProgress_POP.visibility = View.GONE
        }
    }
}
