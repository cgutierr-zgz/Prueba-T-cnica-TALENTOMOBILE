package es.carlosgutimo.pruebatecnica

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_accounts.*


class AccountsActivity : AppCompatActivity() {
    private var myClipboard: ClipboardManager? = null
    private var myClip: ClipData? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_accounts)

        // We assign the App Title
        title = getString(R.string.account_name)

        // We load the account information from the intent
        val bundle = intent.extras

        // We assign every UI component it's value
        accountIBAN_Activity.text = bundle!!.getString("IBAN")
        accountName_Activity.text = bundle.getString("Name")
        accountCurrency_Activity.text = bundle.getString("Currency")
        accountBalance_Activity.text = bundle.getInt("Balance").toString()

        // We handle IBAN Copy to clipboard after long press
        myClipboard =
            getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        accountIBAN_Activity.setOnLongClickListener {
            val text: String = accountIBAN_Activity.text.toString()
            if (text != "") {
                myClip = ClipData.newPlainText("text", text)
                myClipboard!!.setPrimaryClip(myClip!!)
                Toast.makeText(this, getString(R.string.iban_copied), Toast.LENGTH_SHORT).show()
            }
            true
        }
        if (bundle.getString("Type") == "SAVING") {
            hideProgress.visibility = View.VISIBLE
            progress_account.max = bundle.getInt("Progress")
            progress_account.progress = bundle.getInt("Balance")
            goal_current.text = bundle.getInt("Balance").toString()
            goal_total.text = bundle.getInt("Progress").toString()
        }
    }
}
