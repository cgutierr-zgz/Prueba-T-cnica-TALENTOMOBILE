package es.carlosgutimo.pruebatecnica.`class`

// This class is the one used for storing the data of each account in an ArrayList
class Accounts(
    var balance: Int,
    var currency: String,
    var id: Int,
    var name: String,
    var number: String,
    var type: String,
    var alias: String,
    var visibility: Boolean,
    var iban: String,
    var linkedAccount: Int,
    var productName: String,
    var productType: Int,
    var savingsTargetReached: Int,
    var targetAmount: Int
)